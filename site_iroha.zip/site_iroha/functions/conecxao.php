<?php
$hostname = 'localhost';  
$username = 'usr_site_iroha';  
$password = 'uma_senha';  
$database = 'DB_site_iroha';  

//senha 1928462917@19A2aaowx


$mysqli = mysqli_connect($hostname, $username, $password, $database);

if ($mysqli->connect_error) {
    header("Location: falha_na_conn.php");
    die();
}

?>
