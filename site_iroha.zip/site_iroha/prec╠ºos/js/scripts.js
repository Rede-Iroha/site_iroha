function rtoi(){

    real=document.getElementById("real").value;

    if(real<=0){real=0;document.getElementById("real").value=0;}
    valordolar=real/5;

    valoriroha=valordolar/1000;

    document.getElementById("iroha").value=valoriroha;
}

function itor(){

    iroha=document.getElementById("iroha").value;
    if(iroha<=0){iroha=0;document.getElementById("iroha").value=0;}
    valoreall=iroha*5000;

    document.getElementById("real").value=valoreall;

}