var xhr = new XMLHttpRequest()



xhr.onreadystatechange = function(){

    if(xhr.readyState == 4){
        console.log("ok")
        if(xhr.status==200){
            console.log("status 200 ")
        }
    }else{
        console.log("indo para outra rota")
    }
    xhr.onload=()=>{
        // utilizavel para resposta
        resultado=xhr.response
        resultado2=xhr.responseType
        /* CODIGO DOS ERROS
   0=  erro_no_envio_de_dados
   1=  erro_nos_dados
   2=  ja_existe_uma_transação_em_andamento
   3=  grupo_bloqueado
   4=  erro no bloco
   5=  erro na senha
   6=  erro nos dados do bloco ou senha
   7=  valor_de_bloco_insuficiente
   8=  erro no ciclo
   9=  erro na criptografia
 */
            // -azul      .style.backgroundColor="rgba(135,200,255,0.95)";
            // -vermelho  .style.backgroundColor="rgba(200,80,80,0.95)";
        if(resultado=="0"){console.log("erro_no_envio_de_dados")
                            // alert("Erro no sistema")
                             
                            document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                            document.getElementById("s-02").innerText="Erro no envio";

                             
                            document.getElementById("s-03").innerText="Os dados do envio parecem não estar corretos, verifique os campos e tente novamente !";}
                            
        if(resultado=="1"){console.log("erro_nos_dados")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Erro no envio";

                           document.getElementById("s-03").innerText="Os dados do envio parecem não estar corretos, verifique os campos e tente novamente !";}

        if(resultado=="2"){console.log("ja_existe_uma_transação_em_andamento")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Ja existe uma transação em andamento";

                           document.getElementById("s-03").innerText="Foi averiguado que a existe uma transação em andamento, espere ela ser concluida e tente novamente !";}

        if(resultado=="3"){console.log("grupo_bloqueado")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Grupo bloqueado";

                           document.getElementById("s-03").innerText="No momento o grupo esta bloqueado para realizar as operações financeiras !";}

        if(resultado=="4"){console.log("erro no bloco")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Erro no bloco";

                           document.getElementById("s-03").innerText="Existe um erro em um dos blocos selecionados,verifique se o numero dos blocos estão corretos em ultimo caso tente executar uma sincronização&Revisão do bloco !";}
                           

        if(resultado=="5"){console.log("erro na senha")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Erro na senha";

                           document.getElementById("s-03").innerText="A senha digitada parece estar incorreta !";}

        if(resultado=="6"){console.log("erro nos dados do bloco ou senha")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Erro na senha ou bloco";

                           document.getElementById("s-03").innerText="O bloco parece não estar de acordo com a senha, verifique os dados !";}

        if(resultado=="7"){console.log("valor_de_bloco_insuficiente")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Valor insuficiente";

                           document.getElementById("s-03").innerText="O valor do bloco é inferior ao valor da ordem !";}

        if(resultado=="8"){console.log("erro no ciclo")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Erro no ciclo";

                           document.getElementById("s-03").innerText="O bloco esta em conflito com o ciclo do nodo !";}
                           

        if(resultado=="9"){console.log("erro na criptografia")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Erro na criptografia";

                           document.getElementById("s-03").innerText="Não foi possivel criar a ordem de envio por uma falha no modulo de criação criptografica !";}

        if(resultado=="sucesso"){console.log("sucesso")
                           // alert("Cadatrado com sucesso")
                           document.getElementById("s-00").style.backgroundColor="rgba(200,80,80,0.95)";
                           document.getElementById("s-02").innerText="Transação realizada com sucesso, guarde sua nova senha !";

                           document.getElementById("s-03").innerText=resultado;}

        
       // console.log(resultado)
        
        
    }

}
 

function eniar_valor(){
      
     endereco="endereco=";
     senha="senha=";
     destino="destino=";
     valor="valor=";
     grupo="grupo=";
     grupoenv="grupoenv=";
     nvsenha="nvsenha=";

     endereco_entrada=document.getElementById("end").value;
     senha_entrada=document.getElementById("senh").value;
     destino_entrada=document.getElementById("dest").value;
     valor_entrada=document.getElementById("val").value;
     grupo_entrada=document.getElementById("grup").value;
     grupo_env_entrada=document.getElementById("grup-dest").value;
     nova_senha_entrada=document.getElementById("nsenh").value;
     
     
    var cap=endereco+endereco_entrada+"&"+senha+senha_entrada+"&"+destino+destino_entrada+"&"+valor+valor_entrada+"&"+grupo+grupo_entrada+"&"+grupoenv+grupo_env_entrada+"&"+nvsenha+nova_senha_entrada;
    
    
    var dados=[cap];
    
    

    console.log(dados)
    xhr.open("POST","http://www.localhost/3/realiza_transacao.php",true);
    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xhr.setRequestHeader("Access-Control-Allow-Origin","*");
    xhr.send(dados);

    //console.log(xhr.response)
    //console.log(xhr.responseText)

}

function inicio(){

    window.location.assign("http://www.localhost/teste/index.php");
}